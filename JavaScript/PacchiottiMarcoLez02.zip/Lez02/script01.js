//singola riga
/* piu
righe */
var vecchiamaniera = "funziona ancora";
let nuovamaniera = "con scope visabilita limitata";
const IVA = 0.22;
console.log(typeof IVA);
