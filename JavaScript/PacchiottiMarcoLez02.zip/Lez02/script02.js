let a = 5;
let b = 7;

let result = (a > b) ? 'ciao' : 'belllaaa';
console.log(result)
/*switch (a) {
    case a > b:
        console.log("a>b")
        break;
    case a = b:
        console.log("a=b")
        break;
    case a < b:
        console.log("a<b")
        break;
    default:
        console.log("a")
        break;
}
/*
if (a > b) {
    console.log("A maggiore di B")
} else if (a == b) {
    console.log("A uguale di B")
} else {
    console.log("A minore di B")
}*/
