let parola = 'pippo'
let password = "password"
console.log(parola.toLocaleUpperCase())
if (parola == 'pippo' && password == 'password') {
    console.log('logged')
}
const collezione = []
collezione.push('pisolo')
collezione.push('eolo')
collezione.push('mammolo')
collezione.push('gongolo')
collezione.push('numa pompilio')
let lungezza = collezione.length
for (var i of collezione) {
    console.log(i)
}


