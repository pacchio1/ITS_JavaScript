var tot = 0;
function saluta() {
    console.log('ciao')
    tot = 5
}
function addizione(a, b) {
    return a + b;
}
function sottrazione(a, b) {
    return a - b;
}
saluta()
console.log(tot, addizione(90, 14), sottrazione(90, 80))
