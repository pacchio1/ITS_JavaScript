for (let i = 0; i < 10; i++) {
    console.log(i)
}
for (let i = 10; i >= 0; i--) {
    console.log(i)
}
let gira = true;
while (gira) {
    if (Math.random() > 0.8)
        break;
}
do {
    console.log("adkjfòlsdajfòklsjsdalkfgjsaklgjòklasjfgòklajl")
} while (false);
